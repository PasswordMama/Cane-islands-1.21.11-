package com.canefarm;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.block.Hopper;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;

public class CaneIslands extends JavaPlugin implements Listener {

    // ------------------------------------------------------------------ constants
    static final String WORLD_NAME = "cane_islands";
    static final int MIN_Y = 60, MAX_Y = 80;           // vertical scan range for farms
    static final List<int[]> ORDER = new ArrayList<>(); // order extra chunks are added around the start chunk

    static {
        for (int r = 1; r <= 2; r++)
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (Math.max(Math.abs(dx), Math.abs(dz)) == r) ORDER.add(new int[]{dx, dz});
    }

    // ------------------------------------------------------------------ data classes
    static class PD {
        final UUID id;
        String name = "Unknown";
        int slot, extra, day = 1, bestDay = 0, timeLeft = 1800, rewardGrowth, rewardTime;
        long submitted, totalCane;
        boolean completed, flyOwned, flyOn;
        double coins;
        final Map<String, Integer> bought = new HashMap<>();
        final List<Integer> pending = new ArrayList<>();

        PD(UUID id) {
            this.id = id;
        }

        int lvl(String k) {
            return bought.getOrDefault(k, 0);
        }
    }

    static class Special {
        final String type;
        final int x, y, z;
        final UUID owner;

        Special(String type, int x, int y, int z, UUID owner) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.z = z;
            this.owner = owner;
        }

        String key() {
            return x + "," + y + "," + z;
        }

        String ser() {
            return type + "|" + x + "|" + y + "|" + z + "|" + owner;
        }

        static Special parse(String s) {
            String[] p = s.split("\\|");
            if (p.length < 5) return null;
            try {
                return new Special(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), UUID.fromString(p[4]));
            } catch (Exception e) {
                return null;
            }
        }
    }

    static class ShopItem {
        final String id, name;
        final Material icon;
        final double price;
        final int max;
        final String[] desc;
        final boolean glow;
        final BiPredicate<Player, PD> apply;

        ShopItem(String id, Material icon, String name, double price, int max, String[] desc, boolean glow, BiPredicate<Player, PD> apply) {
            this.id = id;
            this.icon = icon;
            this.name = name;
            this.price = price;
            this.max = max;
            this.desc = desc;
            this.glow = glow;
            this.apply = apply;
        }
    }

    static class ShopHolder implements InventoryHolder {
        final int page;
        Inventory inv;

        ShopHolder(int page) {
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class Rw {
        final String desc;
        final BiConsumer<Player, PD> act;

        Rw(String desc, BiConsumer<Player, PD> act) {
            this.desc = desc;
            this.act = act;
        }
    }

    static class VoidGen extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World w, Random r) {
            return new Location(w, 8.5, 65, 8.5);
        }
    }

    static class PlainsBiomes extends BiomeProvider {
        @Override
        public Biome getBiome(WorldInfo wi, int x, int y, int z) {
            return Biome.PLAINS;
        }

        @Override
        public List<Biome> getBiomes(WorldInfo wi) {
            return List.of(Biome.PLAINS);
        }
    }

    // ------------------------------------------------------------------ fields
    World world;
    final Map<UUID, PD> players = new HashMap<>();
    final Map<Long, UUID> chunkOwners = new HashMap<>();
    final Map<String, Special> specials = new LinkedHashMap<>();
    final List<ShopItem> shop = new ArrayList<>();
    final Map<String, PotionEffectType> effects = new LinkedHashMap<>();
    final Random rng = new Random();
    NamespacedKey KEY_INF, KEY_SPECIAL;
    File dataFile;
    boolean dirty;
    int nextSlot = 0;

    double baseChance, perLevel, maxChance, coinsPerCane, priceMult, reqMult;
    int timerMinutes, harvestTicks;
    long capReq;

    // ------------------------------------------------------------------ lifecycle
    @Override
    public void onEnable() {
        getConfig().addDefault("growth.base-chance", 0.03);
        getConfig().addDefault("growth.per-level", 0.015);
        getConfig().addDefault("growth.max-chance", 0.5);
        getConfig().addDefault("timer.minutes", 30);
        getConfig().addDefault("coins-per-cane", 0.5);
        getConfig().addDefault("shop.price-multiplier", 2.0);
        getConfig().addDefault("quota.multiplier", 2.0);
        getConfig().addDefault("quota.cap", 0);
        getConfig().addDefault("harvester.interval-ticks", 20);
        getConfig().options().copyDefaults(true);
        saveConfig();
        baseChance = getConfig().getDouble("growth.base-chance");
        perLevel = getConfig().getDouble("growth.per-level");
        maxChance = getConfig().getDouble("growth.max-chance");
        timerMinutes = getConfig().getInt("timer.minutes");
        coinsPerCane = getConfig().getDouble("coins-per-cane");
        priceMult = getConfig().getDouble("shop.price-multiplier");
        reqMult = getConfig().getDouble("quota.multiplier");
        capReq = getConfig().getLong("quota.cap");
        harvestTicks = Math.max(5, getConfig().getInt("harvester.interval-ticks"));

        KEY_INF = new NamespacedKey(this, "infinite");
        KEY_SPECIAL = new NamespacedKey(this, "special");
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");

        WorldCreator wc = new WorldCreator(WORLD_NAME);
        wc.generator(new VoidGen());
        wc.biomeProvider(new PlainsBiomes());
        wc.environment(World.Environment.NORMAL);
        wc.generateStructures(false);
        world = wc.createWorld();
        if (world == null) {
            getLogger().severe("Could not create island world! Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        world.setSpawnLocation(8, 65, 8);

        buildShop();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        String[] cmds = {"start", "canehome", "canesubmit", "caneday", "caneinfo", "canerewards", "canetop", "caneshop", "isfly", "caneadmin"};
        for (String c : cmds) {
            if (getCommand(c) != null) getCommand(c).setExecutor((CommandExecutor) this::onCommand);
        }

        var sch = getServer().getScheduler();
        sch.runTaskTimer(this, this::secondTick, 20L, 20L);
        sch.runTaskTimer(this, this::fastTick, 5L, 5L);
        sch.runTaskTimer(this, this::growthTick, 40L, 40L);
        sch.runTaskTimer(this, this::harvesterTick, harvestTicks, harvestTicks);
        sch.runTaskTimer(this, this::hopperTick, 10L, 10L);
        sch.runTaskTimer(this, this::perkTick, 100L, 100L);
        sch.runTaskTimer(this, () -> {
            if (dirty) saveData();
        }, 1200L, 1200L);
    }

    @Override
    public void onDisable() {
        if (world != null) saveData();
    }

    // ------------------------------------------------------------------ helpers
    static Component txt(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    void msg(CommandSender s, String m) {
        s.sendMessage(txt("&6[Cane] &f" + m));
    }

    static String fmt(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.0001) return String.format(Locale.US, "%,.0f", v);
        return String.format(Locale.US, "%,.1f", v);
    }

    static String fmt(long v) {
        return String.format(Locale.US, "%,d", v);
    }

    static String mmss(int s) {
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    static String nice(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    static long chunkKey(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    static String keyOf(Block b) {
        return b.getX() + "," + b.getY() + "," + b.getZ();
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack l : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), l);
    }

    ItemStack named(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(txt(s));
        im.lore(l);
        it.setItemMeta(im);
        return it;
    }

    // ------------------------------------------------------------------ island geometry
    int baseX(PD d) {
        return (d.slot % 64) * 8 + 3;
    }

    int baseZ(PD d) {
        return (d.slot / 64) * 8 + 3;
    }

    Location home(PD d) {
        return new Location(world, baseX(d) * 16 + 8.5, 65, baseZ(d) * 16 + 8.5, 0f, 0f);
    }

    List<int[]> chunksOf(PD d) {
        List<int[]> l = new ArrayList<>();
        l.add(new int[]{baseX(d), baseZ(d)});
        for (int i = 0; i < d.extra && i < ORDER.size(); i++) {
            int[] o = ORDER.get(i);
            l.add(new int[]{baseX(d) + o[0], baseZ(d) + o[1]});
        }
        return l;
    }

    void indexChunks(PD d) {
        for (int[] c : chunksOf(d)) chunkOwners.put(chunkKey(c[0], c[1]), d.id);
    }

    static boolean isWaterCol(int lx) {
        return (lx % 3 == 1 && lx <= 13) || lx == 15;
    }

    void buildChunk(int cx, int cz, boolean plant) {
        world.getChunkAt(cx, cz);
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = cx * 16 + lx, z = cz * 16 + lz;
                world.getBlockAt(x, 63, z).setType(Material.DIRT, false);
                boolean water = isWaterCol(lx);
                world.getBlockAt(x, 64, z).setType(water ? Material.WATER : Material.SAND, false);
                if (plant && !water && lz == 7) world.getBlockAt(x, 65, z).setType(Material.SUGAR_CANE, false);
            }
        }
    }

    boolean addChunk(PD d) {
        if (d.extra >= ORDER.size()) return false;
        int[] o = ORDER.get(d.extra);
        d.extra++;
        int cx = baseX(d) + o[0], cz = baseZ(d) + o[1];
        chunkOwners.put(chunkKey(cx, cz), d.id);
        buildChunk(cx, cz, false);
        dirty = true;
        return true;
    }

    boolean canBuild(Player p, Location l) {
        if (!l.getWorld().equals(world)) return true;
        if (p.hasPermission("caneislands.admin")) return true;
        UUID o = chunkOwners.get(chunkKey(l.getBlockX() >> 4, l.getBlockZ() >> 4));
        return o != null && o.equals(p.getUniqueId());
    }

    void deny(Player p) {
        p.sendActionBar(txt("&cYou can only build on your own island chunks!"));
    }

    // ------------------------------------------------------------------ quota / days
    long required(int day) {
        double v = Math.pow(reqMult, day - 1);
        if (v > 4.0e18) v = 4.0e18;
        long r = (long) v;
        if (r < 1) r = 1;
        if (capReq > 0 && r > capReq) r = capReq;
        return r;
    }

    int timeFor(PD d) {
        return timerMinutes * 60 + 300 * (d.lvl("timeext") + d.rewardTime);
    }

    int growthLevel(PD d) {
        return d.rewardGrowth + d.lvl("growth");
    }

    double dropChance(PD d) {
        return 0.2 * d.lvl("doubledrop");
    }

    void submit(PD d, long amt) {
        if (amt <= 0) return;
        d.totalCane += amt;
        d.coins += amt * coinsPerCane * (1.0 + 0.10 * d.lvl("coinboost"));
        dirty = true;
        if (!d.completed) {
            d.submitted += amt;
            if (d.submitted >= required(d.day)) completeDay(d);
        }
    }

    void completeDay(PD d) {
        d.completed = true;
        Player p = Bukkit.getPlayer(d.id);
        boolean first = d.day > d.bestDay;
        int rewardDay = d.day <= 100 ? d.day : 1 + rng.nextInt(100);
        if (first) {
            d.bestDay = d.day;
            if (p != null) applyReward(p, d, rewardDay, d.day > 100);
            else d.pending.add(rewardDay);
        }
        if (p != null) {
            msg(p, "&a&lDay " + d.day + " complete! &7Use &e/caneday &7to start Day " + (d.day + 1) + ".");
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            if (!first)
                msg(p, "&7No reward - you already claimed this day. New rewards start again at Day " + (d.bestDay + 1) + ".");
        }
        dirty = true;
    }

    void failDay(Player p, PD d) {
        int old = d.day;
        d.day = 1;
        d.submitted = 0;
        d.completed = false;
        d.timeLeft = timeFor(d);
        dirty = true;
        msg(p, "&c&lYou failed Day " + old + "! &cYou're back to Day 1. Rewards you already earned won't repeat until you pass Day " + (d.bestDay + 1) + ".");
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.6f, 1f);
    }

    // ------------------------------------------------------------------ rewards
    Rw reward(int rd) {
        List<String> ds = new ArrayList<>();
        List<BiConsumer<Player, PD>> acts = new ArrayList<>();
        final double coins = rd * 2.0 + 5;
        ds.add("+" + fmt(coins) + " coins");
        acts.add((p, d) -> d.coins += coins);

        if (rd == 1) {
            ds.add("Starter pack: 32 Sugar Cane");
            acts.add((p, d) -> give(p, new ItemStack(Material.SUGAR_CANE, 32)));
        }
        switch (rd % 10) {
            case 1, 4, 6 -> {
                ds.add("Growth Boost +1");
                acts.add((p, d) -> d.rewardGrowth += 1);
            }
            case 2 -> {
                ds.add("Chunk Hopper");
                acts.add((p, d) -> give(p, specialItem("chunkhopper")));
            }
            case 3 -> {
                ds.add("Harvester");
                acts.add((p, d) -> give(p, specialItem("harvester")));
            }
            case 5 -> {
                ds.add("Auto Submit Chest");
                acts.add((p, d) -> give(p, specialItem("autosubmit")));
            }
            case 7 -> {
                Material[] inf = {Material.DIRT, Material.SAND, Material.GLASS, Material.HOPPER, Material.CHEST};
                final Material mm = inf[(rd / 10) % 5];
                ds.add("Infinite " + nice(mm));
                acts.add((p, d) -> give(p, infinite(mm)));
            }
            case 8 -> {
                final int amt = 32 + rd;
                ds.add(amt + " Sugar Cane");
                acts.add((p, d) -> give(p, new ItemStack(Material.SUGAR_CANE, amt)));
            }
            case 9 -> {
                final double bonus = rd * 10.0;
                ds.add("Coin pouch: +" + fmt(bonus) + " coins");
                acts.add((p, d) -> d.coins += bonus);
            }
            case 0 -> {
                ds.add("Free Chunk (1,000 coins if you own them all) + Growth Boost +2");
                acts.add((p, d) -> {
                    if (!addChunk(d)) d.coins += 1000;
                    d.rewardGrowth += 2;
                });
            }
            default -> {
            }
        }
        if (rd % 25 == 0) {
            ds.add("+5 minutes on your daily timer");
            acts.add((p, d) -> d.rewardTime += 1);
        }
        return new Rw(String.join(", ", ds), (p, d) -> {
            for (BiConsumer<Player, PD> a : acts) a.accept(p, d);
        });
    }

    void applyReward(Player p, PD d, int rd, boolean random) {
        Rw r = reward(rd);
        r.act.accept(p, d);
        String head = random ? "&6Random reward (from Day " + rd + "): " : "&6Day reward: ";
        msg(p, head + "&f" + r.desc);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        dirty = true;
    }

    // ------------------------------------------------------------------ special / infinite items
    ItemStack infinite(Material m) {
        ItemStack it = new ItemStack(m, m.getMaxStackSize());
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&b\u221E Infinite " + nice(m)));
        im.lore(List.of(txt("&7Never runs out when placed!")));
        im.setEnchantmentGlintOverride(true);
        im.getPersistentDataContainer().set(KEY_INF, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(im);
        return it;
    }

    ItemStack specialItem(String type) {
        Material m;
        String name;
        List<String> lore = new ArrayList<>();
        switch (type) {
            case "chunkhopper" -> {
                m = Material.HOPPER;
                name = "&6Chunk Hopper";
                lore.add("&7Sucks up every item dropped in its chunk.");
                lore.add("&7Put a chest or barrel below it to store them!");
            }
            case "autosubmit" -> {
                m = Material.CHEST;
                name = "&6Auto Submit Chest";
                lore.add("&7Any sugar cane inside is automatically");
                lore.add("&7submitted to your daily quota.");
            }
            default -> {
                m = Material.OBSERVER;
                name = "&6Harvester";
                lore.add("&7Breaks sugar cane once it is 2 blocks tall,");
                lore.add("&7leaving the bottom block to keep growing.");
                lore.add("&7Works on the whole chunk it is placed in.");
            }
        }
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(txt(s));
        im.lore(l);
        im.setEnchantmentGlintOverride(true);
        im.getPersistentDataContainer().set(KEY_SPECIAL, PersistentDataType.STRING, type);
        it.setItemMeta(im);
        return it;
    }

    boolean isInf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(KEY_INF, PersistentDataType.BYTE);
    }

    String specialOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(KEY_SPECIAL, PersistentDataType.STRING);
    }

    // ------------------------------------------------------------------ shop definition
    void add(String id, Material icon, String name, double price, int max, boolean glow, String[] desc, BiPredicate<Player, PD> apply) {
        shop.add(new ShopItem(id, icon, name, price, max, desc, glow, apply));
    }

    void inf(String id, Material m, double price) {
        add(id, m, "&b\u221E Infinite " + nice(m), price, 0, true, new String[]{"&7Place it forever - it never runs out!"}, (p, d) -> {
            give(p, infinite(m));
            return true;
        });
    }

    void pack(String id, Material m, int amt, double price) {
        add(id, m, "&e" + amt + "x " + nice(m), price, 0, false, new String[]{"&7A handy stack for your island."}, (p, d) -> {
            give(p, new ItemStack(m, amt));
            return true;
        });
    }

    void perk(String id, Material icon, String name, double price, int max, String... desc) {
        add(id, icon, name, price, max, false, desc, (p, d) -> true);
    }

    void effect(String id, Material icon, String name, double price, int max, PotionEffectType t, String... desc) {
        perk(id, icon, name, price, max, desc);
        effects.put(id, t);
    }

    void buildShop() {
        // requested items
        inf("inf_dirt", Material.DIRT, 20);
        inf("inf_sand", Material.SAND, 20);
        inf("inf_glass", Material.GLASS, 20);
        inf("inf_hopper", Material.HOPPER, 20);
        inf("inf_chest", Material.CHEST, 20);
        add("chunkhopper", Material.HOPPER, "&6Chunk Hopper", 100, 0, true,
                new String[]{"&7Sucks up every item dropped in its chunk.", "&7Put a chest below it to store the cane!"},
                (p, d) -> {
                    give(p, specialItem("chunkhopper"));
                    return true;
                });
        add("autosubmit", Material.CHEST, "&6Auto Submit Chest", 100, 0, true,
                new String[]{"&7Sugar cane inside is submitted automatically.", "&7Combine with a Chunk Hopper!"},
                (p, d) -> {
                    give(p, specialItem("autosubmit"));
                    return true;
                });
        add("harvester", Material.OBSERVER, "&6Harvester", 100, 0, true,
                new String[]{"&7Breaks cane at 2 blocks tall (bottom keeps growing).", "&7Only breaks it - a Chunk Hopper or you collect it.", "&7Covers the whole chunk it is placed in."},
                (p, d) -> {
                    give(p, specialItem("harvester"));
                    return true;
                });
        add("chunk", Material.GRASS_BLOCK, "&aNew Chunk", 2500, ORDER.size(), true,
                new String[]{"&7Expands your island by one more chunk.", "&7Max " + ORDER.size() + " extra chunks."},
                (p, d) -> {
                    if (!addChunk(d)) {
                        msg(p, "&cYou already own every chunk!");
                        return false;
                    }
                    msg(p, "&aA new chunk was added around your island!");
                    return true;
                });
        add("flight", Material.FEATHER, "&bFlight", 1000, 1, true,
                new String[]{"&7Fly forever!", "&eUse /isfly after buying this to be able to fly"},
                (p, d) -> {
                    d.flyOwned = true;
                    return true;
                });

        // more infinite blocks
        inf("inf_redsand", Material.RED_SAND, 20);
        inf("inf_coarse", Material.COARSE_DIRT, 20);
        inf("inf_podzol", Material.PODZOL, 25);
        inf("inf_grass", Material.GRASS_BLOCK, 25);
        inf("inf_stonebricks", Material.STONE_BRICKS, 20);
        inf("inf_pane", Material.GLASS_PANE, 15);
        inf("inf_torch", Material.TORCH, 15);
        inf("inf_ladder", Material.LADDER, 15);
        inf("inf_scaffold", Material.SCAFFOLDING, 15);
        inf("inf_barrel", Material.BARREL, 25);
        add("inf_water", Material.WATER_BUCKET, "&b\u221E Infinite Water Bucket", 60, 0, true,
                new String[]{"&7A water bucket that never empties."}, (p, d) -> {
                    give(p, infinite(Material.WATER_BUCKET));
                    return true;
                });

        // growth / economy perks
        perk("growth", Material.BONE_MEAL, "&aGrowth Boost", 50, 0,
                "&7Your sugar cane grows faster. Stacks forever!");
        perk("doubledrop", Material.GOLDEN_HOE, "&6Bonus Drops", 150, 10,
                "&7+20% chance per level for extra cane", "&7from harvesters and hand-breaking.");
        perk("coinboost", Material.GOLD_INGOT, "&eCoin Boost", 250, 10,
                "&7+10% coins from every submit per level.");
        perk("timeext", Material.CLOCK, "&bExtra Time", 200, 6,
                "&7+5 minutes on your daily timer per level.");

        // potion perks
        effect("speed", Material.SUGAR, "&bSpeed", 40, 3, PotionEffectType.SPEED, "&7Permanent Speed. Each level is stronger.");
        effect("jump", Material.RABBIT_FOOT, "&aJump Boost", 40, 3, PotionEffectType.JUMP_BOOST, "&7Permanent Jump Boost.");
        effect("nightvision", Material.GOLDEN_CARROT, "&9Night Vision", 60, 1, PotionEffectType.NIGHT_VISION, "&7See clearly all night.");
        effect("waterbreath", Material.HEART_OF_THE_SEA, "&3Water Breathing", 60, 1, PotionEffectType.WATER_BREATHING, "&7Breathe underwater.");
        effect("saturation", Material.COOKED_BEEF, "&6Never Hungry", 120, 1, PotionEffectType.SATURATION, "&7Your hunger bar stays full.");
        effect("regen", Material.GHAST_TEAR, "&cRegeneration", 150, 2, PotionEffectType.REGENERATION, "&7Heal over time.");
        effect("resist", Material.IRON_CHESTPLATE, "&7Resistance", 200, 2, PotionEffectType.RESISTANCE, "&7Take less damage.");
        effect("slowfall", Material.FEATHER, "&fSlow Falling", 80, 1, PotionEffectType.SLOW_FALLING, "&7Float gently down.");
        effect("fireres", Material.MAGMA_CREAM, "&6Fire Resistance", 80, 1, PotionEffectType.FIRE_RESISTANCE, "&7Immune to fire and lava.");
        effect("health", Material.GLISTERING_MELON_SLICE, "&dHealth Boost", 200, 5, PotionEffectType.HEALTH_BOOST, "&7More hearts per level.");

        // packs
        add("caneseeds", Material.SUGAR_CANE, "&e16x Sugar Cane", 10, 0, false, new String[]{"&7Extra cane to plant."}, (p, d) -> {
            give(p, new ItemStack(Material.SUGAR_CANE, 16));
            return true;
        });
        pack("p_bucket", Material.BUCKET, 1, 20);
        pack("p_water", Material.WATER_BUCKET, 1, 30);
        pack("p_composter", Material.COMPOSTER, 4, 20);
        pack("p_bed", Material.RED_BED, 1, 40);
        pack("p_sign", Material.OAK_SIGN, 16, 15);
        pack("p_cake", Material.CAKE, 1, 30);
        pack("p_beef", Material.COOKED_BEEF, 64, 30);
        pack("p_carrot", Material.GOLDEN_CARROT, 32, 40);
        pack("p_rocket", Material.FIREWORK_ROCKET, 64, 25);
        pack("p_lantern", Material.LANTERN, 16, 20);
        pack("p_sealantern", Material.SEA_LANTERN, 32, 40);
        pack("p_glowstone", Material.GLOWSTONE, 32, 30);
        pack("p_quartz", Material.QUARTZ_BLOCK, 64, 40);
        pack("p_bricks", Material.BRICKS, 64, 30);
        pack("p_oak", Material.OAK_PLANKS, 64, 20);
        pack("p_cherry", Material.CHERRY_PLANKS, 64, 25);
        pack("p_shulker", Material.SHULKER_BOX, 1, 150);
        pack("p_enderchest", Material.ENDER_CHEST, 1, 120);
        pack("p_nametag", Material.NAME_TAG, 1, 30);
        pack("p_totem", Material.TOTEM_OF_UNDYING, 1, 400);
        pack("p_elytra", Material.ELYTRA, 1, 500);

        // redstone / farm engineering
        pack("r_observer", Material.OBSERVER, 8, 40);
        pack("r_piston", Material.PISTON, 8, 40);
        pack("r_sticky", Material.STICKY_PISTON, 8, 50);
        pack("r_slime", Material.SLIME_BLOCK, 16, 50);
        pack("r_honey", Material.HONEY_BLOCK, 16, 50);
        pack("r_redstone", Material.REDSTONE, 64, 25);
        pack("r_repeater", Material.REPEATER, 8, 25);
        pack("r_comparator", Material.COMPARATOR, 8, 30);
        pack("r_lever", Material.LEVER, 8, 15);
        pack("r_dropper", Material.DROPPER, 8, 30);
        pack("r_dispenser", Material.DISPENSER, 8, 30);

        // tools
        add("t_axe", Material.NETHERITE_AXE, "&5Cane Axe", 300, 0, true,
                new String[]{"&7Netherite axe, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.NETHERITE_AXE);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
        add("t_pick", Material.DIAMOND_PICKAXE, "&bCane Pickaxe", 200, 0, true,
                new String[]{"&7Diamond pickaxe, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.DIAMOND_PICKAXE);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
        add("t_shovel", Material.DIAMOND_SHOVEL, "&bCane Shovel", 150, 0, true,
                new String[]{"&7Diamond shovel, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.DIAMOND_SHOVEL);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
    }

    double priceOf(PD d, ShopItem s) {
        return Math.min(s.price * Math.pow(priceMult, d.lvl(s.id)), 1.0e15);
    }

    ItemStack iconFor(PD d, ShopItem s) {
        int n = d.lvl(s.id);
        ItemStack it = new ItemStack(s.icon);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(s.name));
        List<Component> lore = new ArrayList<>();
        for (String line : s.desc) lore.add(txt(line.startsWith("&") ? line : "&7" + line));
        lore.add(txt(" "));
        if (s.max > 0 && n >= s.max) {
            lore.add(txt("&c&lSOLD OUT &7(" + n + "/" + s.max + ")"));
        } else {
            double price = priceOf(d, s);
            lore.add(txt("&6Price: &f" + fmt(price) + " coins"));
            lore.add(txt(s.max > 0 ? "&7Owned: " + n + "/" + s.max : "&7Bought: " + n));
            lore.add(txt("&8Price doubles every time you buy."));
            lore.add(txt(d.coins + 1e-9 >= price ? "&aClick to buy!" : "&cNot enough coins"));
        }
        if (s.glow) im.setEnchantmentGlintOverride(true);
        im.lore(lore);
        it.setItemMeta(im);
        return it;
    }

    void fillShop(Inventory inv, PD d, int page) {
        inv.clear();
        int pages = (shop.size() + 44) / 45;
        for (int i = 0; i < 45; i++) {
            int idx = page * 45 + i;
            if (idx >= shop.size()) break;
            inv.setItem(i, iconFor(d, shop.get(idx)));
        }
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);
        if (page > 0) inv.setItem(45, named(Material.ARROW, "&ePrevious page"));
        if (page < pages - 1) inv.setItem(53, named(Material.ARROW, "&eNext page"));
        inv.setItem(49, named(Material.GOLD_INGOT, "&6Your coins: &f" + fmt(d.coins),
                "&7Earn 0.5 coins for every cane you submit.", "&7Page " + (page + 1) + "/" + pages));
    }

    void openShop(Player p, PD d, int page) {
        int pages = (shop.size() + 44) / 45;
        page = Math.max(0, Math.min(page, pages - 1));
        ShopHolder h = new ShopHolder(page);
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lCane Shop"));
        h.inv = inv;
        fillShop(inv, d, page);
        p.openInventory(inv);
    }

    void buy(Player p, PD d, ShopItem s) {
        int n = d.lvl(s.id);
        if (s.max > 0 && n >= s.max) {
            msg(p, "&cYou already have the maximum of this item!");
            return;
        }
        double price = priceOf(d, s);
        if (d.coins + 1e-9 < price) {
            msg(p, "&cYou need &e" + fmt(price) + " &ccoins (you have &e" + fmt(d.coins) + "&c).");
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        if (!s.apply.test(p, d)) return;
        d.coins -= price;
        d.bought.merge(s.id, 1, Integer::sum);
        dirty = true;
        applyEffects(p, d);
        msg(p, "&aBought &f" + s.name.replaceAll("&[0-9a-fk-or]", "") + " &afor &e" + fmt(price) + " &acoins. Next price: &e" + fmt(priceOf(d, s)));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    @EventHandler
    public void onShopClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ShopHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int slot = e.getRawSlot();
        if (slot == 45 && h.page > 0) {
            int np = h.page - 1;
            getServer().getScheduler().runTask(this, () -> openShop(p, d, np));
        } else if (slot == 53 && h.page < (shop.size() + 44) / 45 - 1) {
            int np = h.page + 1;
            getServer().getScheduler().runTask(this, () -> openShop(p, d, np));
        } else if (slot >= 0 && slot < 45) {
            int idx = h.page * 45 + slot;
            if (idx < shop.size()) {
                buy(p, d, shop.get(idx));
                fillShop(top, d, h.page);
            }
        }
    }

    @EventHandler
    public void onShopDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof ShopHolder) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ perks / flight
    void applyEffects(Player p, PD d) {
        for (Map.Entry<String, PotionEffectType> en : effects.entrySet()) {
            int lvl = d.lvl(en.getKey());
            if (lvl > 0) p.addPotionEffect(new PotionEffect(en.getValue(), 600, lvl - 1, true, false, true));
        }
    }

    void applyFly(Player p, PD d) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        if (d.flyOwned && d.flyOn) {
            if (!p.getAllowFlight()) p.setAllowFlight(true);
        }
    }

    void perkTick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            applyEffects(p, d);
            applyFly(p, d);
        }
    }

    // ------------------------------------------------------------------ ticking tasks
    void secondTick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            long req = required(d.day);
            if (!d.completed) {
                d.timeLeft--;
                if (d.timeLeft <= 0) {
                    failDay(p, d);
                    req = required(d.day);
                } else if (d.timeLeft == 300 || d.timeLeft == 60 || d.timeLeft == 10) {
                    msg(p, "&c" + mmss(d.timeLeft) + " left to finish Day " + d.day + "! (" + fmt(d.submitted) + "/" + fmt(req) + ")");
                }
                p.sendActionBar(txt("&6Day " + d.day + " &7| &f" + fmt(d.submitted) + "/" + fmt(req) + " cane &7| &c" + mmss(Math.max(d.timeLeft, 0))));
            } else {
                p.sendActionBar(txt("&aDay " + d.day + " complete! &7Use &e/caneday &7for the next day."));
            }
        }
        sleepCheck();
        autoSubmitTick();
    }

    void sleepCheck() {
        boolean sleeping = false;
        for (Player p : world.getPlayers()) {
            if (p.isDeeplySleeping()) {
                sleeping = true;
                break;
            }
        }
        if (!sleeping) return;
        long t = world.getTime();
        if ((t >= 12541 && t <= 23458) || world.hasStorm()) {
            world.setTime(0);
            world.setStorm(false);
            world.setThundering(false);
        }
    }

    void fastTick() {
        for (Player p : world.getPlayers()) {
            if (p.getLocation().getY() < 20) {
                PD d = players.get(p.getUniqueId());
                p.setFallDistance(0f);
                p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
                if (d != null) p.teleport(home(d));
                else p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
            }
        }
    }

    void growthTick() {
        for (PD d : players.values()) {
            double chance = Math.min(maxChance, baseChance + perLevel * growthLevel(d));
            for (int[] c : chunksOf(d)) {
                if (!world.isChunkLoaded(c[0], c[1])) continue;
                int bx = c[0] << 4, bz = c[1] << 4;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        for (int y = MIN_Y; y <= MAX_Y; y++) {
                            Block b = world.getBlockAt(bx + lx, y, bz + lz);
                            if (b.getType() != Material.SUGAR_CANE) continue;
                            if (b.getRelative(BlockFace.DOWN).getType() == Material.SUGAR_CANE) continue; // only bases
                            int h = 1;
                            Block top = b;
                            while (h < 8 && top.getRelative(BlockFace.UP).getType() == Material.SUGAR_CANE) {
                                top = top.getRelative(BlockFace.UP);
                                h++;
                            }
                            if (h >= 3) continue; // natural max height - never broken here
                            Block above = top.getRelative(BlockFace.UP);
                            if (above.getType() == Material.AIR && rng.nextDouble() < chance) {
                                above.setType(Material.SUGAR_CANE, false);
                            }
                        }
                    }
                }
            }
        }
    }

    void harvesterTick() {
        for (Special s : new ArrayList<>(specials.values())) {
            if (!s.type.equals("harvester")) continue;
            if (!world.isChunkLoaded(s.x >> 4, s.z >> 4)) continue;
            Block hb = world.getBlockAt(s.x, s.y, s.z);
            if (hb.getType() != Material.OBSERVER) {
                specials.remove(s.key());
                dirty = true;
                continue;
            }
            PD d = players.get(s.owner);
            int bx = (s.x >> 4) << 4, bz = (s.z >> 4) << 4;
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    for (int y = MIN_Y; y <= MAX_Y; y++) {
                        Block c = world.getBlockAt(bx + lx, y, bz + lz);
                        if (c.getType() != Material.SUGAR_CANE) continue;
                        if (c.getRelative(BlockFace.DOWN).getType() == Material.SUGAR_CANE) continue;
                        int h = 1;
                        while (h < 8 && c.getRelative(0, h, 0).getType() == Material.SUGAR_CANE) h++;
                        if (h < 2) continue; // only break once 2+ blocks tall
                        for (int i = h - 1; i >= 1; i--) {
                            Block t = c.getRelative(0, i, 0);
                            t.breakNaturally();
                            if (d != null) extraDrop(d, t.getLocation().add(0.5, 0.5, 0.5));
                        }
                    }
                }
            }
        }
    }

    void extraDrop(PD d, Location loc) {
        double chance = dropChance(d);
        if (chance <= 0) return;
        int n = (int) chance;
        if (rng.nextDouble() < chance - n) n++;
        if (n > 0) world.dropItemNaturally(loc, new ItemStack(Material.SUGAR_CANE, n));
    }

    void hopperTick() {
        for (Special s : new ArrayList<>(specials.values())) {
            if (!s.type.equals("chunkhopper")) continue;
            if (!world.isChunkLoaded(s.x >> 4, s.z >> 4)) continue;
            Block b = world.getBlockAt(s.x, s.y, s.z);
            if (b.getType() != Material.HOPPER) {
                specials.remove(s.key());
                dirty = true;
                continue;
            }
            Hopper st = (Hopper) b.getState();
            Inventory inv = st.getInventory();
            for (Entity en : world.getChunkAt(s.x >> 4, s.z >> 4).getEntities()) {
                if (en instanceof Item it) {
                    ItemStack is = it.getItemStack();
                    Map<Integer, ItemStack> left = inv.addItem(is.clone());
                    if (left.isEmpty()) it.remove();
                    else it.setItemStack(left.values().iterator().next());
                }
            }
            Block below = b.getRelative(BlockFace.DOWN);
            if (below.getState() instanceof Container c) {
                Inventory out = c.getInventory();
                for (int i = 0; i < inv.getSize(); i++) {
                    ItemStack it = inv.getItem(i);
                    if (it == null || it.getType() == Material.AIR) continue;
                    Map<Integer, ItemStack> left = out.addItem(it.clone());
                    inv.setItem(i, left.isEmpty() ? null : left.values().iterator().next());
                }
            }
        }
    }

    void autoSubmitTick() {
        for (Special s : new ArrayList<>(specials.values())) {
            if (!s.type.equals("autosubmit")) continue;
            if (!world.isChunkLoaded(s.x >> 4, s.z >> 4)) continue;
            Block b = world.getBlockAt(s.x, s.y, s.z);
            if (b.getType() != Material.CHEST) {
                specials.remove(s.key());
                dirty = true;
                continue;
            }
            Chest c = (Chest) b.getState();
            Inventory inv = c.getInventory();
            long total = 0;
            ItemStack[] cont = inv.getContents();
            for (int i = 0; i < cont.length; i++) {
                ItemStack it = cont[i];
                if (it != null && it.getType() == Material.SUGAR_CANE) {
                    total += it.getAmount();
                    inv.setItem(i, null);
                }
            }
            if (total > 0) {
                PD d = players.get(s.owner);
                if (d != null) {
                    submit(d, total);
                    Player op = Bukkit.getPlayer(s.owner);
                    if (op != null) msg(op, "&aAuto Submit Chest submitted &e" + fmt(total) + " &acane.");
                }
            }
        }
    }

    // ------------------------------------------------------------------ world protection / events
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        PD d = players.get(p.getUniqueId());
        if (d == null) {
            getServer().getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) msg(p, "Welcome! Type &e/start &fto get your own cane island!");
            }, 40L);
            return;
        }
        d.name = p.getName();
        applyFly(p, d);
        if (!d.pending.isEmpty()) {
            for (int rd : new ArrayList<>(d.pending)) applyReward(p, d, rd, false);
            d.pending.clear();
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        PD d = players.get(e.getPlayer().getUniqueId());
        if (d != null) {
            e.setRespawnLocation(home(d));
            Player p = e.getPlayer();
            getServer().getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) {
                    applyFly(p, d);
                    applyEffects(p, d);
                }
            }, 5L);
        }
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().getWorld().equals(world) && e.getEntity() instanceof Monster) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        Block f = e.getBlock(), t = e.getToBlock();
        if (!f.getWorld().equals(world)) return;
        UUID a = chunkOwners.get(chunkKey(f.getX() >> 4, f.getZ() >> 4));
        UUID b = chunkOwners.get(chunkKey(t.getX() >> 4, t.getZ() >> 4));
        if (b == null || !b.equals(a)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null || e.getAction() == Action.PHYSICAL) return;
        if (!b.getWorld().equals(world)) return;
        if (!canBuild(e.getPlayer(), b.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlaceProtect(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        String sp = specialOf(e.getItemInHand());
        if (sp != null && !b.getWorld().equals(world)) {
            e.setCancelled(true);
            msg(p, "&cThis can only be placed on your cane island.");
            return;
        }
        if (!b.getWorld().equals(world)) return;
        if (!canBuild(p, b.getLocation())) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlaceDone(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        ItemStack it = e.getItemInHand();
        String sp = specialOf(it);
        if (sp != null) {
            Block b = e.getBlock();
            UUID owner = chunkOwners.get(chunkKey(b.getX() >> 4, b.getZ() >> 4));
            if (owner == null) owner = p.getUniqueId();
            specials.put(keyOf(b), new Special(sp, b.getX(), b.getY(), b.getZ(), owner));
            dirty = true;
            msg(p, "&aPlaced " + (sp.equals("chunkhopper") ? "Chunk Hopper" : sp.equals("autosubmit") ? "Auto Submit Chest" : "Harvester") + "!");
        }
        if (isInf(it)) {
            EquipmentSlot hs = e.getHand();
            ItemStack copy = it.clone();
            copy.setAmount(copy.getMaxStackSize());
            getServer().getScheduler().runTask(this, () -> {
                ItemStack cur = p.getInventory().getItem(hs);
                if (cur == null || cur.getType() == Material.AIR || cur.isSimilar(copy)) p.getInventory().setItem(hs, copy);
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        Player p = e.getPlayer();
        if (!b.getWorld().equals(world)) return;
        if (!canBuild(p, b.getLocation())) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        Special sp = specials.remove(keyOf(b));
        if (sp != null) {
            dirty = true;
            e.setDropItems(false);
            if (p.getGameMode() != GameMode.CREATIVE)
                world.dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), specialItem(sp.type));
            return;
        }
        if (b.getType() == Material.SUGAR_CANE) {
            PD d = players.get(p.getUniqueId());
            if (d != null) extraDrop(d, b.getLocation().add(0.5, 0.5, 0.5));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Player p = e.getPlayer();
        if (e.getBlock().getWorld().equals(world) && !canBuild(p, e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        ItemStack hand = p.getInventory().getItem(e.getHand());
        if (hand != null && isInf(hand)) e.setItemStack(hand.clone());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        Player p = e.getPlayer();
        if (e.getBlock().getWorld().equals(world) && !canBuild(p, e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler
    public void onCraftPrep(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix()) {
            if (i != null && (isInf(i) || specialOf(i) != null)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ commands
    @SuppressWarnings("unused")
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if (n.equals("caneadmin")) return admin(s, a);
        if (!(s instanceof Player p)) {
            s.sendMessage("Players only.");
            return true;
        }
        PD d = players.get(p.getUniqueId());
        if (n.equals("start")) {
            cmdStart(p, d);
            return true;
        }
        if (d == null) {
            msg(p, "&cYou don't have an island yet. Use &e/start&c!");
            return true;
        }
        switch (n) {
            case "canehome" -> {
                p.teleport(home(d));
                msg(p, "&aWelcome home!");
            }
            case "canesubmit" -> cmdSubmit(p, d);
            case "caneday" -> cmdDay(p, d);
            case "caneinfo" -> cmdInfo(p, d);
            case "canerewards" -> cmdRewards(p, d);
            case "canetop" -> cmdTop(p);
            case "caneshop" -> openShop(p, d, 0);
            case "isfly" -> cmdFly(p, d);
            default -> {
            }
        }
        return true;
    }

    void cmdStart(Player p, PD existing) {
        if (existing != null) {
            msg(p, "&cYou already have an island! Use &e/canehome &cto go back.");
            return;
        }
        PD d = new PD(p.getUniqueId());
        d.name = p.getName();
        d.slot = nextSlot++;
        d.timeLeft = timeFor(d);
        players.put(d.id, d);
        indexChunks(d);
        buildChunk(baseX(d), baseZ(d), true);
        give(p, new ItemStack(Material.SUGAR_CANE, 8));
        p.teleport(home(d));
        dirty = true;
        saveData();
        msg(p, "&aYour island is ready! Farm sugar cane, then &e/canesubmit &ato hand it in.");
        msg(p, "&7Day 1 needs &e1 &7cane. Each day doubles. You have &e" + mmss(d.timeLeft) + " &7per day.");
        msg(p, "&7Use &e/caneinfo&7, &e/caneshop&7, &e/canetop&7, &e/caneday&7, &e/canerewards&7.");
    }

    void cmdSubmit(Player p, PD d) {
        long total = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && it.getType() == Material.SUGAR_CANE) {
                total += it.getAmount();
                inv.setItem(i, null);
            }
        }
        if (total == 0) {
            msg(p, "&cYou have no sugar cane in your inventory!");
            return;
        }
        double before = d.coins;
        submit(d, total);
        msg(p, "&aSubmitted &e" + fmt(total) + " &acane! &7(+" + fmt(d.coins - before) + " coins)");
        if (!d.completed) msg(p, "&7Progress: &f" + fmt(d.submitted) + "/" + fmt(required(d.day)));
    }

    void cmdDay(Player p, PD d) {
        if (!d.completed) {
            msg(p, "&cFinish Day " + d.day + " first! &7(" + fmt(d.submitted) + "/" + fmt(required(d.day)) + ", " + mmss(Math.max(0, d.timeLeft)) + " left)");
            return;
        }
        d.day++;
        d.completed = false;
        d.submitted = 0;
        d.timeLeft = timeFor(d);
        dirty = true;
        msg(p, "&6&lDay " + d.day + " started! &fSubmit &e" + fmt(required(d.day)) + " &fcane within &e" + mmss(d.timeLeft) + "&f.");
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }

    void cmdInfo(Player p, PD d) {
        p.sendMessage(txt("&6&l=== Cane Island ==="));
        p.sendMessage(txt("&eDay: &f" + d.day + " &7(best passed: " + d.bestDay + ")"));
        p.sendMessage(txt("&eQuota: &f" + fmt(d.submitted) + "/" + fmt(required(d.day)) + (d.completed ? " &a(complete - /caneday)" : "")));
        if (!d.completed) p.sendMessage(txt("&eTime left: &f" + mmss(Math.max(0, d.timeLeft))));
        p.sendMessage(txt("&eCoins: &f" + fmt(d.coins)));
        p.sendMessage(txt("&eTotal cane submitted: &f" + fmt(d.totalCane)));
        p.sendMessage(txt("&eChunks: &f" + (d.extra + 1) + "&7/" + (ORDER.size() + 1) + "   &eGrowth level: &f" + growthLevel(d)));
        String next = d.day <= 100 ? reward(d.day).desc : "Random reward from the Day 1-100 pool";
        p.sendMessage(txt("&eThis day's reward: &f" + (d.day > d.bestDay ? next : "&7none (already claimed)")));
    }

    void cmdRewards(Player p, PD d) {
        p.sendMessage(txt("&6&l=== Upcoming Rewards ==="));
        for (int rd = d.day; rd < d.day + 6; rd++) {
            String line = rd <= 100 ? reward(rd).desc : "Random reward from Day 1-100";
            boolean claimed = rd <= d.bestDay;
            p.sendMessage(txt("&eDay " + rd + ": " + (claimed ? "&8" : "&f") + line + (claimed ? " &7(already claimed)" : "")));
        }
    }

    void cmdTop(Player p) {
        List<PD> list = new ArrayList<>(players.values());
        list.sort((x, y) -> Long.compare(y.totalCane, x.totalCane));
        p.sendMessage(txt("&6&l=== Cane Top ==="));
        int shown = Math.min(10, list.size());
        for (int i = 0; i < shown; i++) {
            PD d = list.get(i);
            p.sendMessage(txt("&6#" + (i + 1) + " &f" + d.name + " &7- &e" + fmt(d.totalCane) + " cane &7- &bDay " + d.day));
        }
        int rank = list.indexOf(players.get(p.getUniqueId())) + 1;
        if (rank > 0) p.sendMessage(txt("&7Your rank: &e#" + rank));
    }

    void cmdFly(Player p, PD d) {
        if (!d.flyOwned) {
            msg(p, "&cBuy &bFlight &cin &e/caneshop &cfirst!");
            return;
        }
        d.flyOn = !d.flyOn;
        dirty = true;
        if (d.flyOn) {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) p.setAllowFlight(true);
            msg(p, "&aFlight &2enabled&a.");
        } else {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
            msg(p, "&cFlight disabled.");
        }
    }

    boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("caneislands.admin")) {
            msg(s, "&cNo permission.");
            return true;
        }
        if (a.length < 2) {
            msg(s, "&e/caneadmin <coins|day|chunk> <player> [amount]");
            return true;
        }
        Player t = Bukkit.getPlayerExact(a[1]);
        PD d = t == null ? null : players.get(t.getUniqueId());
        if (d == null) {
            msg(s, "&cPlayer must be online and have an island.");
            return true;
        }
        double val = 0;
        if (a.length > 2) {
            try {
                val = Double.parseDouble(a[2]);
            } catch (NumberFormatException ex) {
                msg(s, "&cInvalid number.");
                return true;
            }
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "coins" -> {
                d.coins += val;
                msg(s, "&aGave " + fmt(val) + " coins.");
            }
            case "day" -> {
                d.day = Math.max(1, (int) val);
                d.submitted = 0;
                d.completed = false;
                d.timeLeft = timeFor(d);
                msg(s, "&aSet day to " + d.day + ".");
            }
            case "chunk" -> msg(s, addChunk(d) ? "&aAdded a chunk." : "&cAlready at max chunks.");
            default -> msg(s, "&e/caneadmin <coins|day|chunk> <player> [amount]");
        }
        dirty = true;
        return true;
    }

    // ------------------------------------------------------------------ persistence
    void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("nextSlot", nextSlot);
        for (PD d : players.values()) {
            String k = "players." + d.id + ".";
            y.set(k + "name", d.name);
            y.set(k + "slot", d.slot);
            y.set(k + "extra", d.extra);
            y.set(k + "day", d.day);
            y.set(k + "bestDay", d.bestDay);
            y.set(k + "timeLeft", d.timeLeft);
            y.set(k + "rewardGrowth", d.rewardGrowth);
            y.set(k + "rewardTime", d.rewardTime);
            y.set(k + "submitted", d.submitted);
            y.set(k + "totalCane", d.totalCane);
            y.set(k + "completed", d.completed);
            y.set(k + "flyOwned", d.flyOwned);
            y.set(k + "flyOn", d.flyOn);
            y.set(k + "coins", d.coins);
            y.set(k + "pending", d.pending);
            for (Map.Entry<String, Integer> en : d.bought.entrySet()) y.set(k + "bought." + en.getKey(), en.getValue());
        }
        List<String> sp = new ArrayList<>();
        for (Special s : specials.values()) sp.add(s.ser());
        y.set("specials", sp);
        try {
            y.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            getLogger().severe("Could not save data: " + ex.getMessage());
        }
    }

    void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        nextSlot = y.getInt("nextSlot", 0);
        ConfigurationSection ps = y.getConfigurationSection("players");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                ConfigurationSection c = ps.getConfigurationSection(k);
                if (c == null) continue;
                PD d;
                try {
                    d = new PD(UUID.fromString(k));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                d.name = c.getString("name", "Unknown");
                d.slot = c.getInt("slot");
                d.extra = c.getInt("extra");
                d.day = Math.max(1, c.getInt("day", 1));
                d.bestDay = c.getInt("bestDay");
                d.timeLeft = c.getInt("timeLeft", 1800);
                d.rewardGrowth = c.getInt("rewardGrowth");
                d.rewardTime = c.getInt("rewardTime");
                d.submitted = c.getLong("submitted");
                d.totalCane = c.getLong("totalCane");
                d.completed = c.getBoolean("completed");
                d.flyOwned = c.getBoolean("flyOwned");
                d.flyOn = c.getBoolean("flyOn");
                d.coins = c.getDouble("coins");
                d.pending.addAll(c.getIntegerList("pending"));
                ConfigurationSection b = c.getConfigurationSection("bought");
                if (b != null) for (String id : b.getKeys(false)) d.bought.put(id, b.getInt(id));
                players.put(d.id, d);
                indexChunks(d);
            }
        }
        for (String line : y.getStringList("specials")) {
            Special s = Special.parse(line);
            if (s != null) specials.put(s.key(), s);
        }
    }
}
